﻿// Made by: Mic Riewe
// Student number: 020027066

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FinalProject_EditForm
{
    public partial class EditForm : Form
    {
        FinalProject.LinqToSqlConnectionClassDataContext dataContext;
        FinalProject.players_statistic[] currPlayer;

        public EditForm()
        {
            InitializeComponent();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            // set background image for panel
            this.BackgroundImage = FinalProject.Properties.Resources.Background;

            dataContext = new FinalProject.LinqToSqlConnectionClassDataContext();
            dataGridView1.DataSource = dataContext.players_statistics;
        }

        // function to load the text fields with chosen record to edit
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (dataGridView1.CurrentCell.RowIndex < 20)
            {
                currPlayer = (from p in dataContext.players_statistics
                                  where p.player_id == dataGridView1.CurrentCell.RowIndex + 1
                                  select p).ToArray();
            }
           else
            {
                
                //Convert.ToInt32(dataGridView1.CurrentCell.RowIndex.Cells[0].Value)
                currPlayer = (from p in dataContext.players_statistics
                              where p.player_id == int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString())
                              select p).ToArray();
            } 
            // fill in the text fields; array onoly has 1 record with index 0
            textBox1.Text = currPlayer[0].player_first_name;
            textBox2.Text = currPlayer[0].player_last_name;
            textBox3.Text = currPlayer[0].country_of_birth;
            textBox4.Text = currPlayer[0].player_age.ToString();
            textBox5.Text = currPlayer[0].goals_scored.ToString();
            textBox6.Text = currPlayer[0].assists_made.ToString();
            textBox7.Text = currPlayer[0].player_number.ToString();
            textBox8.Text = currPlayer[0].player_team;
            textBox9.Text = currPlayer[0].matches_played.ToString();
            textBox10.Text = currPlayer[0].position_on_field;
        }

        // button to submit any changes in the text fields
        private void button1_Click(object sender, EventArgs e)
        {

            // validate text fields for empty or null data and pop up message if any empty
            if (string.IsNullOrEmpty(textBox1.Text) ||
                string.IsNullOrEmpty(textBox2.Text) ||
                string.IsNullOrEmpty(textBox3.Text) ||
                string.IsNullOrEmpty(textBox4.Text) ||
                string.IsNullOrEmpty(textBox5.Text) ||
                string.IsNullOrEmpty(textBox6.Text) ||
                string.IsNullOrEmpty(textBox7.Text) ||
                string.IsNullOrEmpty(textBox8.Text) ||
                string.IsNullOrEmpty(textBox9.Text) ||
                string.IsNullOrEmpty(textBox10.Text))
            {
                MessageBox.Show("Please fill in all fields.");
            }
            else if (!Regex.Match(textBox1.Text, "^[a-zA-Z]*$").Success ||
                    !Regex.Match(textBox2.Text, "^[a-zA-Z]*$").Success ||
                    !Regex.Match(textBox3.Text, "^[a-zA-Z]*$").Success ||
                    !Regex.Match(textBox10.Text, "^[a-zA-Z]*$").Success)
            {
                MessageBox.Show("First and last name have to contain characters only.");
            }
            else if (!Regex.Match(textBox4.Text, "^[0-9]*$").Success ||
                !Regex.Match(textBox5.Text, "^[0-9]*$").Success ||
                !Regex.Match(textBox6.Text, "^[0-9]*$").Success ||
                !Regex.Match(textBox7.Text, "^[0-9]*$").Success ||
                !Regex.Match(textBox9.Text, "^[0-9]*$").Success )
            {
                MessageBox.Show("Age, Goals, Assists, Player Number, and Matches Played must be integers");
            }
            // if all validation passes, submit the data to the database
            else
            {
                var CurrentUserInfo = from p in dataContext.players_statistics
                                      where p.player_id == dataGridView1.CurrentCell.RowIndex + 1
                                      select p;

                foreach (FinalProject.players_statistic updatedPlayer in CurrentUserInfo)
                {
                    //Player updatedPlayer = new Player();
                    updatedPlayer.player_first_name = textBox1.Text;
                    updatedPlayer.player_last_name = textBox2.Text;
                    updatedPlayer.country_of_birth = textBox3.Text;
                    updatedPlayer.player_age = int.Parse(textBox4.Text);
                    updatedPlayer.goals_scored = int.Parse(textBox5.Text);
                    updatedPlayer.assists_made = int.Parse(textBox6.Text);
                    updatedPlayer.player_number = int.Parse(textBox7.Text);
                    updatedPlayer.player_team = textBox8.Text;
                    updatedPlayer.matches_played = int.Parse(textBox9.Text);
                    updatedPlayer.position_on_field = textBox10.Text;

                }
                
                dataContext.SubmitChanges();
                //hiding current form
                this.Hide();
                //open main menu
                FinalProject.MainMenu menu = new FinalProject.MainMenu();
                //showing main menu
                menu.ShowDialog();
                this.Close();

            }

        }

        // button to return to main menu (cancel without changes)
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FinalProject.MainMenu MainMenuForm = new FinalProject.MainMenu();
            MainMenuForm.ShowDialog();
        }

        // button to close the app
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
