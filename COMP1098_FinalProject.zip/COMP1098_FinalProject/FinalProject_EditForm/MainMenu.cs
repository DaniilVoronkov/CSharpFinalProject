﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject_EditForm
{
    public partial class MainMenu : Form
    {
        DataClasses1DataContext dc;

        public MainMenu()
        {
            InitializeComponent();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            dc = new DataClasses1DataContext();
            dataGridView1.DataSource = dc.Players;
        }

    }
}
